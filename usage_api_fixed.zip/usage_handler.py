import json
import boto3
from datetime import datetime, timedelta

def lambda_handler(event, context):
    """사용량 추적 API 핸들러"""
    
    try:
        # CORS 헤더
        headers = {
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Headers': 'Content-Type',
            'Access-Control-Allow-Methods': 'GET,POST,OPTIONS'
        }
        
        if event['httpMethod'] == 'OPTIONS':
            return {
                'statusCode': 200,
                'headers': headers
            }
        
        # 경로에서 user_id와 conversation_id 추출
        path_params = event.get('pathParameters', {})
        user_id = path_params.get('user_id', 'anonymous')
        conversation_id = path_params.get('conversation_id', '')
        
        # DynamoDB 클라이언트
        dynamodb = boto3.resource('dynamodb')
        usage_table = dynamodb.Table('bodo-external-backend-v2-prod-usage')
        
        if event['httpMethod'] == 'GET':
            # 사용량 조회
            try:
                response = usage_table.get_item(
                    Key={
                        'user_id': user_id,
                        'conversation_id': conversation_id
                    }
                )
                
                if 'Item' in response:
                    usage_data = response['Item']
                    used_count = int(usage_data.get('message_count', 0))
                else:
                    used_count = 0
                
                # 사용량 제한 (예: 월 100개 메시지)
                limit = 100
                percentage = min(int((used_count / limit) * 100), 100)
                
                return {
                    'statusCode': 200,
                    'headers': headers,
                    'body': json.dumps({
                        'percentage': percentage,
                        'used': used_count,
                        'limit': limit,
                        'user_id': user_id,
                        'conversation_id': conversation_id
                    })
                }
                
            except Exception as e:
                print(f"사용량 조회 오류: {e}")
                # 오류 시 기본값 반환
                return {
                    'statusCode': 200,
                    'headers': headers,
                    'body': json.dumps({
                        'percentage': 0,
                        'used': 0,
                        'limit': 100
                    })
                }
        
        elif event['httpMethod'] == 'POST':
            # 사용량 업데이트
            body = json.loads(event.get('body', '{}'))
            increment = body.get('increment', 1)
            
            try:
                # 사용량 증가
                usage_table.update_item(
                    Key={
                        'user_id': user_id,
                        'conversation_id': conversation_id
                    },
                    UpdateExpression='ADD message_count :inc SET updated_at = :updated_at',
                    ExpressionAttributeValues={
                        ':inc': increment,
                        ':updated_at': datetime.utcnow().isoformat()
                    }
                )
                
                return {
                    'statusCode': 200,
                    'headers': headers,
                    'body': json.dumps({'message': 'Usage updated'})
                }
                
            except Exception as e:
                print(f"사용량 업데이트 오류: {e}")
                return {
                    'statusCode': 500,
                    'headers': headers,
                    'body': json.dumps({'error': str(e)})
                }
        
        else:
            return {
                'statusCode': 405,
                'headers': headers,
                'body': json.dumps({'error': 'Method not allowed'})
            }
        
    except Exception as e:
        print(f"사용량 API 오류: {e}")
        return {
            'statusCode': 500,
            'headers': {
                'Access-Control-Allow-Origin': '*'
            },
            'body': json.dumps({'error': str(e)})
        }