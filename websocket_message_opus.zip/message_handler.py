import json
import boto3
import os
from datetime import datetime
import uuid

def lambda_handler(event, context):
    """WebSocket 메시지 핸들러 - Claude API 연동"""
    
    try:
        # WebSocket 연결 정보
        connection_id = event['requestContext']['connectionId']
        domain_name = event['requestContext']['domainName']
        stage = event['requestContext']['stage']
        
        # API Gateway Management API 클라이언트
        gateway_api = boto3.client('apigatewaymanagementapi',
            endpoint_url=f"https://{domain_name}/{stage}")
        
        # 메시지 파싱
        body = json.loads(event.get('body', '{}'))
        action = body.get('action', 'sendMessage')
        
        if action == 'sendMessage':
            user_message = body.get('message', '')
            engine_type = body.get('engineType', '11')
            conversation_id = body.get('conversationId')
            user_id = body.get('userId', 'anonymous')
            
            print(f"메시지 처리 시작: {user_message[:100]}...")
            
            # 사용자 메시지를 DynamoDB에 저장
            if conversation_id:
                save_message_to_db(conversation_id, user_id, user_message, 'user')
            
            # AI 시작 신호 전송
            send_message_to_client(gateway_api, connection_id, {
                'type': 'ai_start',
                'timestamp': datetime.utcnow().isoformat() + 'Z'
            })
            
            # Claude API를 통한 응답 생성
            ai_response = await_claude_response(gateway_api, connection_id, user_message, engine_type)
            
            # AI 응답을 DynamoDB에 저장
            if conversation_id and ai_response:
                save_message_to_db(conversation_id, user_id, ai_response, 'assistant')
            
        else:
            # 알 수 없는 액션
            send_message_to_client(gateway_api, connection_id, {
                'type': 'error',
                'message': f'Unknown action: {action}'
            })
        
        return {'statusCode': 200}
        
    except Exception as e:
        print(f"메시지 처리 오류: {e}")
        
        # 오류 메시지 전송 시도
        try:
            gateway_api = boto3.client('apigatewaymanagementapi',
                endpoint_url=f"https://{event['requestContext']['domainName']}/{event['requestContext']['stage']}")
            
            send_message_to_client(gateway_api, event['requestContext']['connectionId'], {
                'type': 'error',
                'message': f'처리 중 오류가 발생했습니다: {str(e)}'
            })
        except:
            pass
        
        return {'statusCode': 500}


def await_claude_response(gateway_api, connection_id, user_message, engine_type):
    """Claude API를 통한 응답 생성 및 스트리밍"""
    
    full_response = ""
    
    try:
        # Bedrock Runtime 클라이언트 초기화
        bedrock_client = boto3.client('bedrock-runtime', region_name='us-east-1')
        
        # 엔진별 시스템 프롬프트
        system_prompts = {
            "11": "당신은 기업 보도자료 전문 분석가입니다. 기업의 보도자료를 분석하여 핵심 내용을 파악하고, 언론사에서 사용할 수 있는 기사 형태로 재작성해주세요.",
            "22": "당신은 정부/공공기관 보도자료 전문 분석가입니다. 정부 및 공공기관의 보도자료를 분석하여 핵심 내용을 파악하고, 언론사에서 사용할 수 있는 기사 형태로 재작성해주세요."
        }
        
        system_prompt = system_prompts.get(engine_type, system_prompts["11"])
        full_message = f"{system_prompt}\n\n분석할 내용:\n{user_message}"
        
        # Bedrock 요청 본문 구성
        body = {
            "anthropic_version": "bedrock-2023-05-31",
            "max_tokens": 4000,
            "temperature": 0.7,
            "messages": [
                {
                    "role": "user",
                    "content": full_message
                }
            ],
            "top_k": 50,
            "top_p": 0.9
        }
        
        print(f"Bedrock 스트리밍 요청 시작...")
        
        # Bedrock 스트리밍 호출
        response = bedrock_client.invoke_model_with_response_stream(
            modelId='anthropic.claude-opus-4-1-20250805-v1:0',
            body=json.dumps(body)
        )
        
        chunk_index = 0
        stream = response.get('body')
        
        if stream:
            for event in stream:
                chunk = event.get('chunk')
                if chunk:
                    chunk_obj = json.loads(chunk.get('bytes').decode())
                    
                    if chunk_obj.get('type') == 'content_block_delta':
                        delta = chunk_obj.get('delta', {})
                        if delta.get('type') == 'text_delta':
                            text = delta.get('text', '')
                            if text:
                                full_response += text
                                print(f"청크 {chunk_index} 전송: {text[:50]}...")
                                
                                # 청크 전송
                                send_message_to_client(gateway_api, connection_id, {
                                    'type': 'ai_chunk',
                                    'chunk': text,
                                    'chunk_index': chunk_index
                                })
                                chunk_index += 1
                    
                    elif chunk_obj.get('type') == 'message_stop':
                        print("스트리밍 완료")
                        break
        
        # 완료 신호 전송
        send_message_to_client(gateway_api, connection_id, {
            'type': 'chat_end',
            'total_chunks': chunk_index,
            'engine': engine_type
        })
        
        print(f"응답 완료: {chunk_index}개 청크 전송")
        return full_response
        
    except Exception as e:
        print(f"Claude API 오류: {e}")
        
        # 오류 메시지 전송
        send_message_to_client(gateway_api, connection_id, {
            'type': 'error',
            'message': f'AI 응답 생성 중 오류: {str(e)}'
        })
        return None


def save_message_to_db(conversation_id, user_id, content, message_type):
    """메시지를 DynamoDB에 저장"""
    
    try:
        dynamodb = boto3.resource('dynamodb')
        messages_table = dynamodb.Table('one-messages')
        conversations_table = dynamodb.Table('one-conversations')
        
        # 메시지 저장
        message_id = str(uuid.uuid4())
        message = {
            'conversation_id': conversation_id,
            'message_id': message_id,
            'user_id': user_id,
            'type': message_type,
            'content': content,
            'timestamp': datetime.utcnow().isoformat(),
            'created_at': datetime.utcnow().isoformat()
        }
        
        messages_table.put_item(Item=message)
        
        # 대화 업데이트 (메시지 수 증가, 마지막 업데이트 시간)
        conversations_table.update_item(
            Key={'conversation_id': conversation_id},
            UpdateExpression='ADD message_count :inc SET updated_at = :updated_at',
            ExpressionAttributeValues={
                ':inc': 1,
                ':updated_at': datetime.utcnow().isoformat()
            }
        )
        
        print(f"메시지 저장 완료: {message_type} - {content[:50]}...")
        
    except Exception as e:
        print(f"메시지 저장 오류: {e}")


def send_message_to_client(gateway_api, connection_id, message):
    """클라이언트에게 메시지 전송"""
    
    try:
        gateway_api.post_to_connection(
            ConnectionId=connection_id,
            Data=json.dumps(message, ensure_ascii=False, default=str)
        )
        
    except Exception as e:
        print(f"메시지 전송 실패 ({connection_id}): {e}")
        raise