import json
import boto3
from datetime import datetime
import uuid

def lambda_handler(event, context):
    """대화 관리 API 핸들러"""
    
    try:
        method = event['httpMethod']
        path = event['path']
        query_params = event.get('queryStringParameters') or {}
        
        # CORS 헤더
        headers = {
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Headers': 'Content-Type,Authorization',
            'Access-Control-Allow-Methods': 'GET,POST,PATCH,DELETE,OPTIONS'
        }
        
        if method == 'OPTIONS':
            return {
                'statusCode': 200,
                'headers': headers
            }
        
        # DynamoDB 클라이언트
        dynamodb = boto3.resource('dynamodb')
        conversations_table = dynamodb.Table('one-conversations')
        messages_table = dynamodb.Table('one-messages')
        
        # userId 추출 (쿼리 파라미터 또는 경로에서)
        user_id = query_params.get('userId', 'anonymous')
        
        if method == 'GET' and path == '/conversations':
            # 대화 목록 조회
            if not user_id or user_id == 'null':
                return {
                    'statusCode': 400,
                    'headers': headers,
                    'body': json.dumps({'error': 'userId is required'})
                }
            
            # 사용자의 대화 목록 조회 (실제로는 GSI 필요하지만 간단히 scan 사용)
            response = conversations_table.scan(
                FilterExpression='contains(conversation_id, :user_id)',
                ExpressionAttributeValues={':user_id': user_id}
            )
            
            conversations = response.get('Items', [])
            
            return {
                'statusCode': 200,
                'headers': headers,
                'body': json.dumps({
                    'conversations': conversations,
                    'total': len(conversations)
                }, default=str)
            }
        
        elif method == 'POST' and path == '/conversations':
            # 새 대화 생성
            body = json.loads(event.get('body', '{}'))
            
            conversation_id = f"{user_id}_{int(datetime.now().timestamp() * 1000)}"
            
            conversation = {
                'conversation_id': conversation_id,
                'user_id': user_id,
                'title': body.get('title', '새 대화'),
                'created_at': datetime.utcnow().isoformat(),
                'updated_at': datetime.utcnow().isoformat(),
                'message_count': 0
            }
            
            conversations_table.put_item(Item=conversation)
            
            return {
                'statusCode': 201,
                'headers': headers,
                'body': json.dumps({
                    'conversation': conversation
                }, default=str)
            }
        
        elif method == 'GET' and '/conversations/' in path:
            # 특정 대화 조회
            conversation_id = path.split('/conversations/')[-1]
            
            # 대화 정보 조회
            conv_response = conversations_table.get_item(
                Key={'conversation_id': conversation_id}
            )
            
            if 'Item' not in conv_response:
                return {
                    'statusCode': 404,
                    'headers': headers,
                    'body': json.dumps({'error': 'Conversation not found'})
                }
            
            # 메시지 조회
            msg_response = messages_table.query(
                KeyConditionExpression='conversation_id = :conv_id',
                ExpressionAttributeValues={':conv_id': conversation_id},
                ScanIndexForward=True  # 시간순 정렬
            )
            
            conversation = conv_response['Item']
            conversation['messages'] = msg_response.get('Items', [])
            
            return {
                'statusCode': 200,
                'headers': headers,
                'body': json.dumps({
                    'conversation': conversation
                }, default=str)
            }
        
        elif method == 'PATCH' and '/conversations/' in path:
            # 대화 업데이트 (제목 변경 등)
            conversation_id = path.split('/conversations/')[-1]
            body = json.loads(event.get('body', '{}'))
            
            update_expression = "SET updated_at = :updated_at"
            expression_values = {':updated_at': datetime.utcnow().isoformat()}
            
            if 'title' in body:
                update_expression += ", title = :title"
                expression_values[':title'] = body['title']
            
            conversations_table.update_item(
                Key={'conversation_id': conversation_id},
                UpdateExpression=update_expression,
                ExpressionAttributeValues=expression_values
            )
            
            return {
                'statusCode': 200,
                'headers': headers,
                'body': json.dumps({'message': 'Updated successfully'})
            }
        
        elif method == 'DELETE' and '/conversations/' in path:
            # 대화 삭제
            conversation_id = path.split('/conversations/')[-1]
            
            # 대화 삭제
            conversations_table.delete_item(
                Key={'conversation_id': conversation_id}
            )
            
            # 관련 메시지들도 삭제 (실제로는 배치 삭제 필요)
            msg_response = messages_table.query(
                KeyConditionExpression='conversation_id = :conv_id',
                ExpressionAttributeValues={':conv_id': conversation_id}
            )
            
            for message in msg_response.get('Items', []):
                messages_table.delete_item(
                    Key={
                        'conversation_id': conversation_id,
                        'message_id': message['message_id']
                    }
                )
            
            return {
                'statusCode': 200,
                'headers': headers,
                'body': json.dumps({'message': 'Deleted successfully'})
            }
        
        else:
            return {
                'statusCode': 404,
                'headers': headers,
                'body': json.dumps({'error': 'Not found'})
            }
        
    except Exception as e:
        print(f"API 오류: {e}")
        return {
            'statusCode': 500,
            'headers': {
                'Access-Control-Allow-Origin': '*'
            },
            'body': json.dumps({'error': str(e)})
        }