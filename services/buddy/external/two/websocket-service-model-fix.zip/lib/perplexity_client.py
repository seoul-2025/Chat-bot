"""
Perplexity API Client - 간단한 웹 검색 통합
"""
import os
import json
import logging
import requests
from typing import Optional

logger = logging.getLogger(__name__)

class PerplexityClient:
    """Perplexity API 클라이언트"""
    
    def __init__(self):
        self.api_key = os.environ.get('PERPLEXITY_API_KEY', '')
        self.api_url = "https://api.perplexity.ai/chat/completions"
        logger.info(f"PerplexityClient initialized with API key: {'Yes' if self.api_key else 'No'}")
        
    def search(self, query: str, enable: bool = True) -> Optional[str]:
        """웹 검색 수행"""
        logger.info(f"Perplexity search called - Enable: {enable}, Has API Key: {bool(self.api_key)}, Query: {query[:50]}...")
        
        if not enable or not self.api_key:
            logger.warning(f"Perplexity search skipped - Enable: {enable}, Has API Key: {bool(self.api_key)}")
            return None
            
        try:
            headers = {
                "Authorization": f"Bearer {self.api_key}",
                "Content-Type": "application/json"
            }
            
            # 최신 모델로 업데이트 (2025년 10월 기준)
            payload = {
                "model": "llama-3.1-sonar-small-128k-chat",  # 유효한 온라인 검색 모델
                "messages": [
                    {
                        "role": "system",
                        "content": "You are a helpful search assistant. Always provide the most recent and accurate information. Answer in Korean. Include dates and sources when available."
                    },
                    {
                        "role": "user",
                        "content": query
                    }
                ],
                "temperature": 0.2,
                "max_tokens": 1500,  # 더 긴 응답 허용
                "search_recency_filter": "day"  # 최근 정보 우선
            }
            
            logger.info(f"Sending request to Perplexity API with model: {payload['model']}")
            response = requests.post(
                self.api_url,
                headers=headers,
                json=payload,
                timeout=30  # 타임아웃 증가
            )
            
            logger.info(f"Perplexity API response status: {response.status_code}")
            
            if response.status_code == 200:
                result = response.json()
                search_result = result['choices'][0]['message']['content']
                logger.info(f"✅ Perplexity search success - Result length: {len(search_result)} chars")
                logger.info(f"Search result preview: {search_result[:200]}...")
                return search_result
            else:
                logger.error(f"❌ Perplexity API error: {response.status_code}")
                logger.error(f"Response content: {response.text[:500]}")
                return None
                
        except Exception as e:
            logger.error(f"Error calling Perplexity API: {str(e)}")
            return None